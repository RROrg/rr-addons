#!/bin/sh

ACTION=$1
INTERFACE=$2

if [ "$ACTION" == "start" ]; then
  /etc/rc.network start "$INTERFACE"
elif [ "$ACTION" == "stop" ]; then
  /etc/rc.network stop "$INTERFACE"
fi
